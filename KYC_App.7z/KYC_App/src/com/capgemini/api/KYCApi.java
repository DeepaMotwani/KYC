package com.capgemini.api;


import java.util.Calendar;
import java.util.Date;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.capgemini.model.KYC;


@Path("KYC")
public class KYCApi {
	
	KYC user= new KYC();
	
	 @POST
	@Path("addUser")
	 @Produces(MediaType.APPLICATION_JSON)
	public KYC addUser(KYC user){
		 
		 Calendar cal = Calendar.getInstance();
		 Date today = cal.getTime();
		 cal.add(Calendar.YEAR, 2); 
		 Date expiry_date = cal.getTime();
		 
		 user.setRegistration_date(today);
		 user.setExpiry_date(expiry_date);
		 
        System.out.println("User added successfully");
        return user;
        
    }

	 @POST
	    @Path("searchUser")
	    @Produces(MediaType.APPLICATION_JSON)
	public KYC searchUser(int user_id){
        KYC user = new KYC();
        if(user.getUser_id()==user_id){
            return user;
        }
        return null;
    }
	
	 public boolean isValidUser(Date date){
	        date=new Date();
	        return user.getRegistration_date().compareTo(date) * date.compareTo(user.getExpiry_date()) >= 0;

	    }
}
