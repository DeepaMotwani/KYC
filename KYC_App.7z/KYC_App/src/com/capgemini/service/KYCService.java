package com.capgemini.service;

public class KYCService {

}
