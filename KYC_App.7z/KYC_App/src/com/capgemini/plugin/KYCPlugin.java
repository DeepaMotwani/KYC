package com.capgemini.plugin;

public class KYCPlugin {

}
