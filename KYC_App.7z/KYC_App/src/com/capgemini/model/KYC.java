package com.capgemini.model;

import java.util.Date;

public class KYC {
	
	    private int user_id;
	    private String name;
	    private int bank_id;
	    private Date registration_date=new Date();
	    private Date expiry_date;

	    public KYC(){}

	    public KYC(int user_id, String name, int bank_id, Date registration_date, Date expiry_date) {
	        this.user_id = user_id;
	        this.name = name;
	        this.bank_id = bank_id;
	        this.registration_date = registration_date;
	        this.expiry_date = expiry_date;
	    }

	    public int getUser_id() {
	        return user_id;
	    }

	    public void setRegistration_date(Date registration_date) {
			this.registration_date = registration_date;
		}

		public String getName() {
	        return name;
	    }

	    public int getBank_id() {
	        return bank_id;
	    }

	    public void setBank_id(int bank_id) {
	        this.bank_id = bank_id;
	    }

	    public Date getRegistration_date() {
	        return registration_date;
	    }

	    public Date getExpiry_date() {
	        return expiry_date;
	    }

	    public void setUser_id(int user_id) {
	        this.user_id = user_id;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public void setExpiry_date(Date expiry_date) {
	        this.expiry_date = expiry_date;
	    }

	    @Override
	    public String toString() {
	        return "KYC{" +
	                "user_id=" + user_id +
	                ", name='" + name + '\'' +
	                ", bank_id=" + bank_id +
	                ", registration_date=" + registration_date +
	                ", expiry_date=" + expiry_date +
	                '}';
	    }
	}



