package com.capgemini.client;

public class KYCClientRPC {

}
