package com.capgemini.flow;

import co.paralleluniverse.fibers.Suspendable;
import com.capgemini.contract.KYCState;
import com.google.common.collect.ImmutableSet;
import net.corda.core.contracts.TransactionResolutionException;
import net.corda.core.crypto.CompositeKey;
import net.corda.core.crypto.CryptoUtilities;
import net.corda.core.crypto.DigitalSignature;
import net.corda.core.crypto.Party;
import net.corda.core.flows.FlowLogic;
import net.corda.core.transactions.SignedTransaction;
import net.corda.core.transactions.TransactionBuilder;
import net.corda.core.transactions.WireTransaction;
import net.corda.core.utilities.ProgressTracker;
import net.corda.flows.FinalityFlow;

import java.io.FileNotFoundException;
import java.security.KeyPair;
import java.security.SignatureException;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Set;

import static kotlin.collections.CollectionsKt.single;

public class KYCFlow {
	public static class Initiator extends FlowLogic<ExampleFlowResult> {

        private final KYCState kycState;
        private List<Party> parties;

        public Initiator(KYCState kycState, List<Party> parties) {
            this.kycState = kycState;
            this.parties = parties;
        }

        private final ProgressTracker progressTracker = new ProgressTracker(
                GENERATING_TRANSACTION,
                SIGNING_TRANSACTION,
                SENDING_TRANSACTION
        );

        private static final ProgressTracker.Step GENERATING_TRANSACTION = new ProgressTracker.Step(
                "Generating transaction based on new KYC.");
        private static final ProgressTracker.Step SIGNING_TRANSACTION = new ProgressTracker.Step(
                "Signing transaction with our private key.");
        private static final ProgressTracker.Step SENDING_TRANSACTION = new ProgressTracker.Step(
                "Sending proposed transaction to other bank for review.");

        @Override public ProgressTracker getProgressTracker() { return progressTracker; }

        @Suspendable
        @Override public ExampleFlowResult call() {

            try {
                //Obtain ref of keypair
                final KeyPair keyPair = getServiceHub().getLegalIdentityKey();
                //obtain ref of notary
                final Party notary = single(getServiceHub().getNetworkMapCache().getNotaryNodes()).getNotaryIdentity();

                //For geenerating transaction
                progressTracker.setCurrentStep(GENERATING_TRANSACTION);

                final TransactionBuilder utx = kycState.generateAgreement(notary);
                //Add timestamp
                final Instant currentTime = getServiceHub().getClock().instant();

                utx.setTime(currentTime, Duration.ofSeconds(30));
                    //Signing the transaction with keypair
                progressTracker.setCurrentStep(SIGNING_TRANSACTION);
                final SignedTransaction partSignedTx = utx.signWith(keyPair).toSignedTransaction(false);

                //Sending to other party
                progressTracker.setCurrentStep(SENDING_TRANSACTION);

                for(Party otherParty:parties) {
                    this.send(otherParty, partSignedTx);
                }

                return new ExampleFlowResult.Success(String.format("Transaction id %s committed to ledger.", partSignedTx.getId()));

            } catch(Exception ex) {

                return new ExampleFlowResult.Failure(ex.getMessage());
            }
        }
    }

    public static class Acceptor extends FlowLogic<ExampleFlowResult> {

        private final Party otherParty;
        private final ProgressTracker progressTracker = new ProgressTracker(
                RECEIVING_TRANSACTION,
                VERIFYING_TRANSACTION,
                SIGNING_TRANSACTION,
                FINALISING_TRANSACTION
        );

        private static final ProgressTracker.Step RECEIVING_TRANSACTION = new ProgressTracker.Step(
                "Receiving proposed transaction from buyer.");
        private static final ProgressTracker.Step VERIFYING_TRANSACTION = new ProgressTracker.Step(
                "Verifying signatures and contract constraints.");
        private static final ProgressTracker.Step SIGNING_TRANSACTION = new ProgressTracker.Step(
                "Signing proposed transaction with our private key.");
        private static final ProgressTracker.Step FINALISING_TRANSACTION = new ProgressTracker.Step(
                "Obtaining notary signature and recording transaction.");

        public Acceptor(Party otherParty) {
            this.otherParty = otherParty;
        }

        @Override public ProgressTracker getProgressTracker() { return progressTracker; }

        @Suspendable
        @Override public ExampleFlowResult call() {
            try {
                    //get ref of keypair of acceptor
                final KeyPair keyPair = getServiceHub().getLegalIdentityKey();

                //Obtain ref to notary
                final Party notary = single(getServiceHub().getNetworkMapCache().getNotaryNodes()).getNotaryIdentity();
                //ref of notary public key
                final CompositeKey notaryPubKey = notary.getOwningKey();


                progressTracker.setCurrentStep(RECEIVING_TRANSACTION);

                final SignedTransaction partSignedTx = receive(SignedTransaction.class, otherParty)
                        .unwrap(tx ->
                        {

                            progressTracker.setCurrentStep(VERIFYING_TRANSACTION);
                            try {
                                    //validating Initiator party signature
                                final WireTransaction wireTx = tx.verifySignatures(CryptoUtilities.getComposite(keyPair.getPublic()), notaryPubKey);
                                    //run contract verify()
                                wireTx.toLedgerTransaction(getServiceHub()).verify();
                            } catch (SignatureException | FileNotFoundException | TransactionResolutionException ex) {
                                throw new RuntimeException(ex);
                            }
                            return tx;
                        });


                progressTracker.setCurrentStep(SIGNING_TRANSACTION);
                    //Signing with Acceptor keypair and adding to transaction
                final DigitalSignature.WithKey mySig = partSignedTx.signWithECDSA(keyPair);
                    //signing the transaction with acceptor signature
                final SignedTransaction signedTx = partSignedTx.plus(mySig);


                progressTracker.setCurrentStep(FINALISING_TRANSACTION);
                final Set<Party> participants = ImmutableSet.of(getServiceHub().getMyInfo().getLegalIdentity(), otherParty);
                //notarizing the transaction and adding to ledger
                subFlow(new FinalityFlow(signedTx, participants));

                return new ExampleFlowResult.Success(String.format("Transaction id %s committed to ledger.", signedTx.getId()));

            } catch (Exception ex) {
                return new ExampleFlowResult.Failure(ex.getMessage());
            }
        }
    }

    public static class ExampleFlowResult {
        public static class Success extends com.capgemini.flow.KYCFlow.ExampleFlowResult {
            private String message;

            private Success(String message) { this.message = message; }

            @Override
            public String toString() { return String.format("Success(%s)", message); }
        }

        public static class Failure extends com.capgemini.flow.KYCFlow.ExampleFlowResult {
            private String message;

            private Failure(String message) { this.message = message; }

            @Override
            public String toString() { return String.format("Failure(%s)", message); }
        }
    }

}
