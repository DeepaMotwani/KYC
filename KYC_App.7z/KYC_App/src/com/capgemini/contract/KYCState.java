package com.capgemini.contract;

public class KYCState {

}
