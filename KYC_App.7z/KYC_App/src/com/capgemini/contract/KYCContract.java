package com.capgemini.contract;

public class KYCContract {

}
