angular.module('bcloyalty').factory('loginService',function($http, $q){
	return{
		getUserDetails: function(){
			var deffered = $q.defer();
			$http.get('static/json/user.json').
			success(function(data, status, headers, config){
				deffered.resolve(data);
			}).
			error(function(data, status, headers, config){
				deffered.reject(data);
			});

			return deffered.promise;
		}
	}
});


