angular.module('bcloyalty').controller('searchCtrl',function($http, $scope,  $state){
	const apiBaseURL = "http://localhost:8080/KYC/";
    var item = $state.params.item;

  /*  $scope.items = [
        { 'Counterparty':'A',
            'UserName': 'ABC',
            'UserID':'101',
            'KycDate': '2011-10-10',
            'KycValidDate':'2016-12-11',
            'KycDoc':'pdf'}];
    $scope.items.push(item);*/

    if($state.params.search){
    	 $http.post(apiBaseURL+"searchUser",item).then(function(response){$state.go('search', {item:response.data}); });
        $scope.search = $state.params.search;
    }
});

