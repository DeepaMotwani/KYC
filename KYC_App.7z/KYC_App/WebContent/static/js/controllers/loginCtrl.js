angular.module('bcloyalty').controller('loginCtrl',function($scope, $rootScope, $state, loginService){

	$rootScope.login = function( ){
		$scope.error = "";
		$scope.loginDetails = {
			  "enrollId": $scope.userId,
			  "enrollSecret": $scope.password
			  };
		loginService.getUserDetails($scope.loginDetails).then(function(result){
			if(result.Failure){
				$scope.error = result;
				return false;
			}
			else if (result.success){
				$state.go('index');
				}
						
		}, function(error){
			$scope.error = error;
		});
	};

});

