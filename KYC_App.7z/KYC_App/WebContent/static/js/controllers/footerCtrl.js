angular.module('bcloyalty').controller('footerCtrl', function($scope){
	
});
