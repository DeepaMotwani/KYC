angular.module('bcloyalty').controller('kycmainCtrl',function($scope,  $state, $http, $location) {
	const apiBaseURL = "http://localhost:8080/KYC/";
    $scope.itemDetail ={};
   /* $scope.items = [
        { 'Counterparty':'A',
            'name': 'ABC',
            'user_id':'101',
            'registration_date': '2011-10-10',
            'expiry_date':'2016-12-11',
            }];*/
    $scope.addRow = function(itemDetail){
        $http.post(apiBaseURL+"addUser",itemDetail).then(function(response){
        	//$state.go('search', {item:response.data});
        	 $state.go('search', {item:itemDetail});
        
        }
        );
        //$state.go('search', {item:itemDetail});
        };
});

  




